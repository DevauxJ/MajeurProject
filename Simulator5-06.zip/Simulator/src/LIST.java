

/**
 * Class LIST
 */
public class LIST {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public LIST () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

}
