

/**
 * Interface Detector
 */
public interface Detector {

  //
  // Fields
  //

  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   * @return       Map
   */
  public Map detection();


}
