
public class Test {

	public static void main(String[] args) {
		Coord b = new Coord(150,3);
		Environnement environnement1 = new Environnement (b,90);
			System.out.println (environnement1);
		
		
	}

}
