
import java.util.*;


/**
 * Class RobotControler
 */
public class RobotControler {

  //
  // Fields
  //

  private Environnement environnement;
  private Robot robot;
  
  //
  // Constructors
  //
  public RobotControler () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of environnement
   * @param newVar the new value of environnement
   */
  private void setEnvironnement (Environnement newVar) {
    environnement = newVar;
  }



  /**
   * Set the value of robot
   * @param newVar the new value of robot
   */
  private void setRobot (Robot newVar) {
    robot = newVar;
  }

  /**
   * Get the value of robot
   * @return the value of robot
   */
  private Robot getRobot () {
    return robot;
  }

  //
  // Other methods
  //

  /**
   * @return       Boolean
   */
  public Boolean north()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean east()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean west()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean south()
  {
	return null;
  }


  /**
   * @return       Map
   */
  public Map getView()
  {
	return null;
  }


  /**
   * @return       Environnement

   * Get the value of environnement
   * @return the value of environnement
   */
  public Environnement getEnvironnement()
  {
	return environnement;
  }


  /**
   * @return       Environnement
   */
  public Environnement getRobotEnvironnement()
  {
	return environnement;
  }


}
