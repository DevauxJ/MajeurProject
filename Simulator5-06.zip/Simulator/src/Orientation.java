
/**
 * 
 * @author justine.devaux
 *Enum qui nous  permettra de donner les directions du robot
 */
public enum Orientation {
	NORTH, SOUTH, EAST, WEST

}
