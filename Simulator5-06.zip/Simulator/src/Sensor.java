
import java.util.*;
import RobotControler.Robot;


/**
 * Class Sensor
 */
public class Sensor implements Detector {

  //
  // Fields
  //

  private void listDetect(){
  
  };
  
  //
  // Constructors
  //
  public Sensor () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of listDetect
   * @param newVar the new value of listDetect
   */
  private void setListDetect (void newVar) {
    listDetect = newVar;
  }

  /**
   * Get the value of listDetect
   * @return the value of listDetect
   */
  private void getListDetect () {
    return listDetect;
  }

  //
  // Other methods
  //

  /**
   * @return       Map
   */
  public Map detection()
  {
  }


}
