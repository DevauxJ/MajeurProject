/**
 * Etat possible d'une case
 * @author justine.devaux
 *
 */
public enum Etat {
	UNKNOWN, FREE, OBSTACLE
}
