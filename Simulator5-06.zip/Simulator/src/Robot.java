
import java.util.*;


/**
 * Class Robot
 */
public class Robot {

  //
  // Fields
  //

  private Coord coord;
  private Orientation Orientation;
  private Map discoveredMap;
  private Detector sensor;
  
  //
  // Constructors
  //
  public Robot () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of coord
   * @param newVar the new value of coord
   */
  private void setCoord (Coord newVar) {
    coord = newVar;
  }

  /**
   * Get the value of coord
   * @return the value of coord
   */
  private Coord getCoord () {
    return coord;
  }

  /**
   * Set the value of Orientation
   * @param newVar the new value of Orientation
   */
  private void setOrientation (Orientation newVar) {
    Orientation = newVar;
  }

  /**
   * Get the value of Orientation
   * @return the value of Orientation
   */
  private Orientation getOrientation () {
    return Orientation;
  }

  /**
   * Set the value of discoveredMap
   * @param newVar the new value of discoveredMap
   */
  private void setDiscoveredMap (Map newVar) {
    discoveredMap = newVar;
  }

  /**
   * Get the value of discoveredMap
   * @return the value of discoveredMap
   */
  private Map getDiscoveredMap () {
    return discoveredMap;
  }

  /**
   * Set the value of sensor
   * @param newVar the new value of sensor
   */
  private void setSensor (Detector newVar) {
    sensor = newVar;
  }

  /**
   * Get the value of sensor
   * @return the value of sensor
   */
  private Detector getSensor () {
    return sensor;
  }

  //
  // Other methods
  //

  /**
   * @return       Boolean
   */
  public Boolean up()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean down()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean left()
  {
	return null;
  }


  /**
   * @return       Boolean
   */
  public Boolean right()
  {
	return null;
  }


  /**
   * @return       Map
   */
  public Map getView()
  {
	return discoveredMap;
  }


}
